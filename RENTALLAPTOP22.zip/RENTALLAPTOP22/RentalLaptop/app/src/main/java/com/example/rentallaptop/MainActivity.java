package com.example.rentallaptop;

import android.app.Activity;

public class MainActivity extends Activity {
}
