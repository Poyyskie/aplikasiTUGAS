package com.example.rentallaptop

data class myContact (
    var submit : String,
    var cancel : String
)