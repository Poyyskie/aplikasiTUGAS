package com.example.rentallaptop.main_ui

const val EXTRA_PESAN = "EXTRA_PESAN"