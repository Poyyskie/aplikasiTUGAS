package com.example.rentallaptop;

import android.app.Activity;

public class ActivityDetail extends Activity {
}
